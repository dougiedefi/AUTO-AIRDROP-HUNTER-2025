Containers
----------

Docker container for development.
