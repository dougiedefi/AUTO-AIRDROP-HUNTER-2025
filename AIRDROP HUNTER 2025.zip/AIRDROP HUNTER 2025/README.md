Run AirdropHunter with `airdrophunter.exe` from the `AIRDROPHUNTERDESKTOP` folder.
